import { test } from '@playwright/test';
import LoginPage from '../pages/LoginPage.js';
import AdminPage from '../pages/Adminpage.js';
import JsonReader from '../reader/JsonReader.js';

const loginData = JsonReader.read('./test-data/loginData.json');

let loginPage;
let adminPage;

test.beforeEach(async ({ page }) => {

    loginPage = new LoginPage(page);
    adminPage = new AdminPage(page);

    await loginPage.openURL('/web/index.php/auth/login');

    await loginPage.validLogin(
        loginData.validLogin.username,
        loginData.validLogin.password
    );

    await loginPage.verifyDashboard();
});


test('TC_001 Verify admin page is loaded successfully', async () => {
    await adminPage.verifyAdminpageLoadedSuccessfully();
    
});