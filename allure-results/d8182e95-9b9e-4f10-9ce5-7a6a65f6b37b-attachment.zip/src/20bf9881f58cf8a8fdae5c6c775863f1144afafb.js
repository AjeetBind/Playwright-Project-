import { test, expect } from '@playwright/test';

test('Test_001 Verify Google homepage', async ({ page }) => {

    await page.goto('https://www.google.com');

    await expect(page).toHaveTitle(/Google/);

     const searchBox = await page.locator("//textarea[@aria-autocomplete='both']");
     await searchBox.fill('Vinay Say'); 
      
     await page.locator("//textarea[@aria-autocomplete='both']")
     .press('Enter');

      await page.locator("//div[@class='u4Uk3c']")
      .click();

    
});