import { test, expect } from '@playwright/test';

test('Test_001 Verify Google homepage', async ({ page }) => {

    await page.goto('https://www.google.com');

    await expect(page).toHaveTitle(/Google/);

     await page.locator("//textarea[@aria-autocomplete='both']");
     await page.fill('Vinay Say');
     await page.press('Enter');

      await page.locator("//div[@class='u4Uk3c']")
      await page.click();

    

});